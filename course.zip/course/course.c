/**
 * @file course.c
 * @author zhanh279
 * @brief in course there are functions of enrollong students, printing courses' information, getting student with higest grade,
 * and a passing function.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief This function enrolls students. It calloc an array with one space for a Student type and keep realloc
 * space if there are more than 1 student, and put students in that array.
 * @return noting
 * @param course Course type
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief Print the course's name, code, total student number and information of each students in the course.
 * @return nothing
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
    // a print function for Student type variables which can print out student's first name, last name, student id, grade and average grade.
}

/**
 * @brief It returns a student with higest average grade in the course.(If there has no student in the course return NULL.)
 * 
 * @param course Course type
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  //set first student's average as higest grade.
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  //compare each students' grade and always swaps the student with higher gread as student and the student's grade as max_average.

  return student;
}
/**
 * @brief count the number of students who pass the course(average grade greater or equal to 50) and calloc an
 * array to store the students who pass the course, then return the array.
 * @param course Course type
 * @param total_passing Integer type
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}